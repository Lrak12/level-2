using UnityEngine;

[RequireComponent(typeof(SphereCollider))]
public sealed class IslandCheckpoint : MonoBehaviour
{
    [SerializeField] private int index;
    [SerializeField] private Renderer marker;
    [SerializeField] private Color activeColor = new Color(0.12f, 0.56f, 0.32f);

    public void Configure(int checkpointIndex, Renderer visual)
    {
        index = checkpointIndex;
        marker = visual;
    }

    public void ConfigureActiveColor(Color color) => activeColor = color;

    private void OnTriggerEnter(Collider other)
    {
        if (other.GetComponentInParent<TribalPlayerController>() == null)
            return;
        if (IslandGameSession.Instance == null)
            return;

        IslandGameSession.Instance.ReachCheckpoint(index);
        if (marker != null)
            marker.material.color = activeColor;
    }
}
