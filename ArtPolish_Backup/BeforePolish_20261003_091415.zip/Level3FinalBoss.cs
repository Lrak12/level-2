using System.Collections;
using UnityEngine;
using UnityEngine.AI;

/// <summary>A telegraphed area attack used only by the Ashen Citadel final boss.</summary>
[RequireComponent(typeof(IslandEnemyAI), typeof(NavMeshAgent))]
public sealed class Level3FinalBoss : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private LineRenderer warningRing;
    [SerializeField, Min(1f)] private float slamRadius = 4.3f;
    [SerializeField, Min(0f)] private float slamDamage = 18f;
    [SerializeField, Min(0.2f)] private float windupSeconds = 1.15f;
    [SerializeField, Min(1f)] private float slamCooldown = 8f;

    private IslandEnemyAI enemy;
    private NavMeshAgent agent;
    private float nextSlamTime;
    private bool slamming;

    public void Configure(Transform player, LineRenderer ring)
    {
        target = player;
        warningRing = ring;
    }

    public void ConfigureAttack(float damage, float cooldown)
    {
        slamDamage = Mathf.Max(0f, damage);
        slamCooldown = Mathf.Max(1f, cooldown);
    }

    private void Awake()
    {
        enemy = GetComponent<IslandEnemyAI>();
        agent = GetComponent<NavMeshAgent>();
        nextSlamTime = Time.time + 4f;
        if (warningRing != null)
            warningRing.enabled = false;
    }

    private void Update()
    {
        if (enemy.IsDead)
        {
            if (warningRing != null)
                warningRing.enabled = false;
            return;
        }

        if (slamming || Time.time < nextSlamTime ||
            (IslandGameSession.Instance != null && IslandGameSession.Instance.BlocksGameplay))
            return;

        if (target == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
                target = player.transform;
        }

        if (target != null && Vector3.Distance(transform.position, target.position) <= 8f)
            StartCoroutine(Slam());
    }

    private IEnumerator Slam()
    {
        slamming = true;
        nextSlamTime = Time.time + slamCooldown;
        enemy.StopAllCoroutines();
        enemy.enabled = false;
        if (agent.isOnNavMesh)
        {
            agent.isStopped = true;
            agent.ResetPath();
        }

        if (warningRing != null)
        {
            warningRing.transform.localPosition = Vector3.up * 0.15f;
            warningRing.widthMultiplier = 0.14f;
            warningRing.enabled = true;
        }

        float elapsed = 0f;
        while (elapsed < windupSeconds && !enemy.IsDead)
        {
            elapsed += Time.deltaTime;
            if (warningRing != null)
                warningRing.widthMultiplier = Mathf.Lerp(0.14f, 0.36f, elapsed / windupSeconds);
            yield return null;
        }

        if (warningRing != null)
            warningRing.enabled = false;

        if (!enemy.IsDead && target != null &&
            (IslandGameSession.Instance == null || !IslandGameSession.Instance.BlocksGameplay))
        {
            Vector3 delta = target.position - transform.position;
            delta.y = 0f;
            if (delta.sqrMagnitude <= slamRadius * slamRadius)
                target.SendMessage("TakeDamage", slamDamage, SendMessageOptions.DontRequireReceiver);
        }

        if (!enemy.IsDead)
        {
            enemy.enabled = true;
            if (agent.isOnNavMesh)
                agent.isStopped = false;
        }
        slamming = false;
    }
}
