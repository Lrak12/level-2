using UnityEngine;

[RequireComponent(typeof(SphereCollider))]
public sealed class Level3HealingPickup : MonoBehaviour
{
    [SerializeField] private Transform floatingVisual;
    [SerializeField, Min(0f)] private float bobHeight = 0.18f;
    [SerializeField, Min(0f)] private float spinDegreesPerSecond = 45f;

    private Vector3 restingLocalPosition;
    private bool collected;

    public void Configure(Transform visual) => floatingVisual = visual;

    private void Start()
    {
        if (floatingVisual != null)
            restingLocalPosition = floatingVisual.localPosition;
    }

    private void Update()
    {
        if (floatingVisual == null || collected)
            return;

        floatingVisual.localPosition = restingLocalPosition +
            Vector3.up * (Mathf.Sin(Time.time * 2.5f) * bobHeight);
        floatingVisual.Rotate(0f, spinDegreesPerSecond * Time.deltaTime, 0f, Space.Self);
    }

    private void OnTriggerEnter(Collider other) => TryCollect(other);

    private void OnTriggerStay(Collider other) => TryCollect(other);

    private void TryCollect(Collider other)
    {
        if (collected ||
            (IslandGameSession.Instance != null && IslandGameSession.Instance.BlocksGameplay))
            return;

        TribalPlayerController player = other.GetComponentInParent<TribalPlayerController>();
        if (player == null || !player.HealToFull())
            return;

        collected = true;
        gameObject.SetActive(false);
    }
}
