using UnityEngine;

[RequireComponent(typeof(SphereCollider))]
public sealed class Level3Relic : MonoBehaviour
{
    [SerializeField] private Renderer crystal;
    private bool collected;

    public void Configure(Renderer visual) => crystal = visual;

    private void OnTriggerEnter(Collider other)
    {
        if (collected || other.GetComponentInParent<TribalPlayerController>() == null)
            return;

        IslandGameSession session = IslandGameSession.Instance;
        if (session == null || session.BlocksGameplay)
            return;

        collected = true;
        session.CollectRelic();
        if (crystal != null)
            crystal.gameObject.SetActive(false);
    }
}
