using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController), typeof(Animator))]
public sealed class TribalPlayerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField, Min(0.1f)] private float walkSpeed = 2.2f;
    [SerializeField, Min(0.1f)] private float runSpeed = 4.5f;
    [SerializeField, Min(1f)] private float rotationSpeed = 12f;
    [SerializeField] private float gravity = -24f;

    [Header("Combat")]
    private const float AttackDuration = 0.9f;
    private const float AttackImpactDelay = 0.28f;
    private const float ComboResetDelay = 0.8f;
    private const float AttackMovementMultiplier = 0.4f;
    [SerializeField, Min(0f)] private float attackDamage = 35f;
    [SerializeField, Min(0.1f)] private float attackReach = 1.6f;
    [SerializeField, Min(1f)] private float maxHealth = 100f;

    [Header("Stamina and dash")]
    [SerializeField, Min(1f)] private float maxStamina = 100f;
    [SerializeField, Min(0f)] private float sprintStaminaPerSecond = 22f;
    [SerializeField, Min(0f)] private float staminaRecoveryPerSecond = 18f;
    [SerializeField, Min(0f)] private float dashStaminaCost = 35f;
    [SerializeField, Min(0.1f)] private float dashSpeed = 12f;
    [SerializeField, Min(0.05f)] private float dashDuration = 0.22f;

    private CharacterController controller;
    private Animator animator;
    private Transform cameraTransform;
    private float verticalVelocity;
    private float health;
    private float stamina;
    private float nextStaminaRecoveryTime;
    private float dashRemaining;
    private Vector3 dashDirection;
    private bool exhausted;
    private bool dead;
    private bool attacking;
    private int comboStep;
    private int queuedComboClicks;
    private float comboResetTime;

    public float Health => health;
    public float MaxHealth => maxHealth;
    public float Stamina => stamina;
    public float MaxStamina => maxStamina;
    public bool IsDead => dead;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        animator = GetComponent<Animator>();
        cameraTransform = Camera.main != null ? Camera.main.transform : null;
        health = maxHealth;
        stamina = maxStamina;
        animator.applyRootMotion = false;
    }

    private void Start()
    {
        SnapToGround();
    }

    private void Update()
    {
        if (dead || (IslandGameSession.Instance != null && IslandGameSession.Instance.BlocksGameplay))
            return;

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
            return;

        if (keyboard.spaceKey.wasPressedThisFrame ||
            (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame))
        {
            QueueComboAttack();
        }

        Vector2 input = Vector2.zero;
        if (keyboard.wKey.isPressed) input.y += 1f;
        if (keyboard.sKey.isPressed) input.y -= 1f;
        if (keyboard.dKey.isPressed) input.x += 1f;
        if (keyboard.aKey.isPressed) input.x -= 1f;
        input = Vector2.ClampMagnitude(input, 1f);

        if (exhausted && stamina >= maxStamina * 0.25f)
            exhausted = false;
        bool wantsSprint = keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed;
        bool running = wantsSprint && !exhausted && stamina > 0f && input.sqrMagnitude > 0.01f;
        if (running)
        {
            stamina = Mathf.Max(0f, stamina - sprintStaminaPerSecond * Time.deltaTime);
            nextStaminaRecoveryTime = Time.time + 0.65f;
            if (stamina <= 0f)
            {
                running = false;
                exhausted = true;
            }
        }
        else if (Time.time >= nextStaminaRecoveryTime)
            stamina = Mathf.Min(maxStamina, stamina + staminaRecoveryPerSecond * Time.deltaTime);
        float moveSpeed = running ? runSpeed : walkSpeed;
        if (attacking)
            moveSpeed *= AttackMovementMultiplier;
        Vector3 forward = cameraTransform != null ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform != null ? cameraTransform.right : Vector3.right;
        forward.y = 0f;
        right.y = 0f;
        forward.Normalize();
        right.Normalize();
        Vector3 direction = forward * input.y + right * input.x;

        if (keyboard.qKey.wasPressedThisFrame && !attacking && dashRemaining <= 0f && stamina >= dashStaminaCost)
        {
            dashDirection = direction.sqrMagnitude > 0.01f ? direction.normalized : transform.forward;
            dashRemaining = dashDuration;
            stamina -= dashStaminaCost;
            nextStaminaRecoveryTime = Time.time + 0.8f;
            if (LevelPresentation.Instance != null)
            {
                LevelPresentation.Instance.Play(LevelSound.Dash, transform.position, .8f);
                LevelPresentation.Instance.Burst(transform.position + Vector3.up * .3f,
                    new Color(.35f, .8f, 1f, .55f), 25, 2f, .14f);
            }
        }
        if (dashRemaining > 0f)
        {
            dashRemaining = Mathf.Max(0f, dashRemaining - Time.deltaTime);
            direction = dashDirection;
            moveSpeed = dashSpeed;
        }

        if (direction.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }

        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;
        verticalVelocity += gravity * Time.deltaTime;

        controller.Move((direction * moveSpeed + Vector3.up * verticalVelocity) * Time.deltaTime);
        float animationSpeed = input.sqrMagnitude < 0.01f ? 0f : running ? 1f : 0.4f;
        animator.SetFloat("Speed", animationSpeed, 0.12f, Time.deltaTime);
    }

    private void QueueComboAttack()
    {
        if (attacking)
        {
            queuedComboClicks = Mathf.Min(queuedComboClicks + 1, 3 - comboStep);
            return;
        }

        if (Time.time > comboResetTime || comboStep >= 3)
            comboStep = 0;
        comboStep++;
        StartCoroutine(PlayComboStep(comboStep));
    }

    private IEnumerator PlayComboStep(int step)
    {
        attacking = true;
        string trigger = "Attack" + step;
        animator.ResetTrigger("Attack1");
        animator.ResetTrigger("Attack2");
        animator.ResetTrigger("Attack3");
        animator.SetTrigger(trigger);
        if (LevelPresentation.Instance != null)
            LevelPresentation.Instance.Swing(transform, step, true);

        yield return new WaitForSeconds(AttackImpactDelay);
        if (!dead)
            ApplyAttackDamage();

        yield return new WaitForSeconds(AttackDuration - AttackImpactDelay);
        attacking = false;
        comboResetTime = Time.time + ComboResetDelay;

        if (!dead && queuedComboClicks > 0)
        {
            queuedComboClicks--;
            comboStep = comboStep >= 3 ? 1 : comboStep + 1;
            StartCoroutine(PlayComboStep(comboStep));
        }
    }

    private void ApplyAttackDamage()
    {
        Vector3 center = transform.position + transform.forward * attackReach;
        foreach (Collider hit in Physics.OverlapSphere(center, 1.2f, ~0, QueryTriggerInteraction.Ignore))
        {
            IslandEnemyAI enemy = hit.GetComponentInParent<IslandEnemyAI>();
            if (enemy != null && !enemy.IsDead)
                enemy.TakeDamage(attackDamage);
        }
    }

    private void SnapToGround()
    {
        bool wasEnabled = controller.enabled;
        controller.enabled = false;

        Vector3 rayOrigin = transform.position + Vector3.up * 8f;
        if (Physics.Raycast(rayOrigin, Vector3.down, out RaycastHit hit, 20f, ~0, QueryTriggerInteraction.Ignore))
        {
            float feetY = transform.position.y;
            Transform leftFoot = animator.GetBoneTransform(HumanBodyBones.LeftToes) ?? animator.GetBoneTransform(HumanBodyBones.LeftFoot);
            Transform rightFoot = animator.GetBoneTransform(HumanBodyBones.RightToes) ?? animator.GetBoneTransform(HumanBodyBones.RightFoot);
            if (leftFoot != null && rightFoot != null)
                feetY = Mathf.Min(leftFoot.position.y, rightFoot.position.y);
            else
            {
                Renderer[] renderers = GetComponentsInChildren<Renderer>();
                if (renderers.Length > 0)
                {
                    feetY = renderers[0].bounds.min.y;
                    for (int i = 1; i < renderers.Length; i++)
                        feetY = Mathf.Min(feetY, renderers[i].bounds.min.y);
                }
            }

            float feetOffset = feetY - transform.position.y;
            transform.position += Vector3.up * (hit.point.y + 0.025f - feetY);

            Transform head = animator.GetBoneTransform(HumanBodyBones.Head);
            float characterHeight = head != null ? head.position.y - feetY + 0.3f : 1.85f;
            controller.height = Mathf.Max(1f, characterHeight);
            controller.center = new Vector3(0f, feetOffset + controller.height * 0.5f, 0f);
        }

        controller.enabled = wasEnabled;
        verticalVelocity = -2f;
    }

    public void TakeDamage(float amount)
    {
        if (dead || dashRemaining > 0f || amount <= 0f)
            return;

        health = Mathf.Max(0f, health - amount);
        if (LevelPresentation.Instance != null)
            LevelPresentation.Instance.Hit(transform, true, health <= 0f);
        if (health > 0f)
            return;

        dead = true;
        attacking = false;
        queuedComboClicks = 0;
        StopAllCoroutines();
        animator.SetFloat("Speed", 0f);
        animator.SetTrigger("Die");
        controller.enabled = false;
    }

    public bool HealToFull()
    {
        if (dead || health >= maxHealth)
            return false;

        health = maxHealth;
        return true;
    }

    public void RespawnAt(Vector3 position)
    {
        StopAllCoroutines();
        controller.enabled = false;
        transform.position = position;
        health = maxHealth;
        stamina = maxStamina;
        dead = false;
        exhausted = false;
        attacking = false;
        dashRemaining = 0f;
        queuedComboClicks = 0;
        comboStep = 0;
        animator.Rebind();
        animator.Update(0f);
        controller.enabled = true;
        SnapToGround();
        if (LevelPresentation.Instance != null)
            LevelPresentation.Instance.Reward(LevelSound.Checkpoint, transform.position, new Color(.25f, .85f, 1f, .7f));
    }
}
