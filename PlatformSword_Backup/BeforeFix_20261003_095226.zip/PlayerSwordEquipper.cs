using UnityEngine;

[RequireComponent(typeof(Animator))]
public sealed class PlayerSwordEquipper : MonoBehaviour
{
    private const string RightSwordResourcePath = "Player/TribalSword";
    private const string LeftSwordResourcePath = "Player/TribalSwordLeft";
    private const string RightSwordName = "PlayerSword_Right";
    private const string LeftSwordName = "PlayerSword_Left";
    private const string PreviousSwordName = "PlayerSword_OneHanded";
    private const string LegacySwordName = "PlayerSword";
    private const float SwordScale = 0.30f;
    private const float GripBlendSpeed = 24f;
    private static readonly Quaternion RightIdleGripRotation = Quaternion.Euler(-1.9f, 0f, 0f);
    private static readonly Quaternion LeftIdleGripRotation = Quaternion.Euler(-11.8f, 0f, 0f);
    private static readonly Quaternion SlashGripRotation = Quaternion.Euler(120f, 0f, 0f);
    private static readonly int Attack1State = Animator.StringToHash("Base Layer.Attack1");
    private static readonly int Attack2State = Animator.StringToHash("Base Layer.Attack2");
    private static readonly int Attack3State = Animator.StringToHash("Base Layer.Attack3");

    private Animator animator;
    private Transform rightSword;
    private Transform leftSword;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void EquipRuntimePlayer()
    {
        TribalPlayerController player = FindFirstObjectByType<TribalPlayerController>();
        if (player == null)
            return;

        PlayerSwordEquipper equipper = player.GetComponent<PlayerSwordEquipper>();
        if (equipper == null)
            equipper = player.gameObject.AddComponent<PlayerSwordEquipper>();
        equipper.Equip();
    }

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    private void Start()
    {
        Equip();
    }

    private void LateUpdate()
    {
        if (animator == null || rightSword == null || leftSword == null)
            return;

        bool attack1 = IsStateActive(Attack1State);
        bool attack2 = IsStateActive(Attack2State);
        bool attack3 = IsStateActive(Attack3State);
        Quaternion rightTarget = rightSword.parent.rotation * RightIdleGripRotation;
        Quaternion leftTarget = leftSword.parent.rotation * LeftIdleGripRotation;
        if (attack3)
        {
            rightTarget = rightSword.parent.rotation * SlashGripRotation;
            leftTarget = leftSword.parent.rotation * SlashGripRotation;
        }
        else if (attack2)
        {
            // The blade's long axis is local +Y. Aim it in world space so the
            // changing hand rotation in the animation cannot turn the point sideways.
            leftTarget = Quaternion.LookRotation(transform.up, transform.forward);
        }
        else if (attack1)
        {
            rightTarget = Quaternion.LookRotation(transform.up, transform.forward);
        }
        float blend = 1f - Mathf.Exp(-GripBlendSpeed * Time.deltaTime);

        rightSword.rotation = Quaternion.Slerp(rightSword.rotation, rightTarget, blend);
        leftSword.rotation = Quaternion.Slerp(leftSword.rotation, leftTarget, blend);
    }

    public void Equip()
    {
        if (animator == null)
            animator = GetComponent<Animator>();
        if (animator == null || !animator.isHuman)
            return;

        Transform rightHand = animator.GetBoneTransform(HumanBodyBones.RightHand);
        Transform leftHand = animator.GetBoneTransform(HumanBodyBones.LeftHand);
        if (rightHand == null || leftHand == null)
            return;

        RemoveSword(rightHand, LegacySwordName);
        RemoveSword(rightHand, PreviousSwordName);
        RemoveSword(rightHand, LeftSwordName);
        RemoveSword(leftHand, LegacySwordName);
        RemoveSword(leftHand, PreviousSwordName);
        RemoveSword(leftHand, RightSwordName);

        rightSword = EquipSword(rightHand, RightSwordResourcePath, RightSwordName, RightIdleGripRotation);
        leftSword = EquipSword(leftHand, LeftSwordResourcePath, LeftSwordName, LeftIdleGripRotation);
    }

    private bool IsStateActive(int stateHash)
    {
        if (animator.GetCurrentAnimatorStateInfo(0).fullPathHash == stateHash)
            return true;

        return animator.IsInTransition(0) && animator.GetNextAnimatorStateInfo(0).fullPathHash == stateHash;
    }

    private Transform EquipSword(Transform hand, string resourcePath, string swordName, Quaternion gripRotation)
    {
        Transform equippedSword = hand.Find(swordName);
        if (equippedSword != null)
        {
            equippedSword.SetLocalPositionAndRotation(Vector3.zero, gripRotation);
            equippedSword.localScale = Vector3.one * SwordScale;
            return equippedSword;
        }

        GameObject swordPrefab = Resources.Load<GameObject>(resourcePath);
        if (swordPrefab == null)
            return null;

        GameObject sword = Instantiate(swordPrefab, hand);
        sword.name = swordName;
        sword.transform.SetLocalPositionAndRotation(Vector3.zero, gripRotation);
        sword.transform.localScale = Vector3.one * SwordScale;

        foreach (Collider swordCollider in sword.GetComponentsInChildren<Collider>(true))
            swordCollider.enabled = false;

        return sword.transform;
    }

    private void RemoveSword(Transform hand, string swordName)
    {
        Transform sword = hand.Find(swordName);
        if (sword == null)
            return;

        if (Application.isPlaying)
            Destroy(sword.gameObject);
        else
            DestroyImmediate(sword.gameObject);
    }
}
